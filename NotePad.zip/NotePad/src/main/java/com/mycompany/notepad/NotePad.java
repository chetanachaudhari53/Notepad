package com.mycompany.notepad;

import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.filechooser.FileNameExtensionFilter;

public class NotePad extends JFrame implements ActionListener, WindowListener {

    JTextArea jta = new JTextArea();
    File fnameContainer;

    public NotePad() {
        Font fnt = new Font("Arial", Font.PLAIN, 15);
        Container con = getContentPane();
        JMenuBar jmb = new JMenuBar();
        JMenu jmfile = new JMenu("File");
        JMenu jmedit = new JMenu("Edit");
        JMenu jmhelp = new JMenu("Help");

        con.setLayout(new BorderLayout());
        JScrollPane sbrText = new JScrollPane(jta);
        sbrText.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        sbrText.setVisible(true);

        jta.setFont(fnt);
        jta.setLineWrap(true);
        jta.setWrapStyleWord(true);

        con.add(sbrText);

        createMenuItem(jmfile, "New");
        createMenuItem(jmfile, "Open");
        createMenuItem(jmfile, "Save");
        jmfile.addSeparator();
        createMenuItem(jmfile, "Exit");

        createMenuItem(jmedit, "Cut");
        createMenuItem(jmedit, "Copy");
        createMenuItem(jmedit, "Paste");

        createMenuItem(jmhelp, "About Notepad");

        jmb.add(jmfile);
        jmb.add(jmedit);
        jmb.add(jmhelp);

        setJMenuBar(jmb);
        setIconImage(Toolkit.getDefaultToolkit().getImage("notepad.gif"));
        addWindowListener(this);
        setSize(500, 500);
        setTitle("Untitled.txt - Notepad");
        setVisible(true);
    }

    public void createMenuItem(JMenu jm, String txt) {
        JMenuItem jmi = new JMenuItem(txt);
        jmi.addActionListener(this);
        jm.add(jmi);
    }

    public void actionPerformed(ActionEvent e) {
        JFileChooser jfc = new JFileChooser();
        String command = e.getActionCommand();

        try {
            if (command.equals("New")) {
                setTitle("Untitled.txt - Notepad");
                jta.setText("");
                fnameContainer = null;
            } else if (command.equals("Open")) {
                int ret = jfc.showOpenDialog(null);
                if (ret == JFileChooser.APPROVE_OPTION) {
                    File fyl = jfc.getSelectedFile();
                    openFile(fyl.getAbsolutePath());
                    setTitle(fyl.getName() + " - Notepad");
                    fnameContainer = fyl;
                }
            } else if (command.equals("Save")) {
                if (fnameContainer != null) {
                    jfc.setCurrentDirectory(fnameContainer.getParentFile());
                    jfc.setSelectedFile(fnameContainer);
                } else {
                    jfc.setSelectedFile(new File("Untitled.txt"));
                }

                int ret = jfc.showSaveDialog(null);
                if (ret == JFileChooser.APPROVE_OPTION) {
                    File fly = jfc.getSelectedFile();
                    saveFile(fly.getAbsolutePath());
                    setTitle(fly.getName());
                    fnameContainer = fly;
                }
            } else if (command.equals("Exit")) {
                exiting();
            } else if (command.equals("Copy")) {
                jta.copy();
            } else if (command.equals("Paste")) {
                jta.paste();
            } else if (command.equals("Cut")) {
                jta.cut();
            } else if (command.equals("About Notepad")) {
                JOptionPane.showMessageDialog(this, "Created by : Chetana", "Notepad", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void openFile(String fname) throws IOException {
        BufferedReader d = new BufferedReader(new FileReader(fname));
        jta.setText("");
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        String l;
        while ((l = d.readLine()) != null) {
            jta.append(l + "\n");
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        d.close();
    }

    public void saveFile(String fname) throws IOException {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        BufferedWriter o = new BufferedWriter(new FileWriter(fname));
        o.write(jta.getText());
        o.close();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    @Override public void windowOpened(WindowEvent e) {}
    @Override public void windowClosing(WindowEvent e) { exiting(); }
    @Override public void windowClosed(WindowEvent e) {}
    @Override public void windowIconified(WindowEvent e) {}
    @Override public void windowDeiconified(WindowEvent e) {}
    @Override public void windowActivated(WindowEvent e) {}
    @Override public void windowDeactivated(WindowEvent e) {}

    public void exiting() {
        System.exit(0);
    }
}
